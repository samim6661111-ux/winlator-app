# Ludashi GTA IV overlay

1. Fork StevenMXZ/Winlator-Ludashi at the 4.1 tag/branch.
2. Copy `overlay/` and `.github/workflows/build.yml` from this zip into the fork's root, commit, push.
3. Actions -> "Build Ludashi GTA IV Edition" -> Run workflow. APK = artifact `Ludashi-GTAIV`.

The workflow runs `overlay/apply.py` (copies files into app/, makes LauncherActivity the launcher),
so the upstream source stays untouched and 4.x updates merge cleanly.
If the fork already has its own workflow, keep it and just add the "Apply GTA IV overlay" step before the build step.

Only `GameLauncher.java` depends on Winlator internals (activity name, extras, drive mapping).
