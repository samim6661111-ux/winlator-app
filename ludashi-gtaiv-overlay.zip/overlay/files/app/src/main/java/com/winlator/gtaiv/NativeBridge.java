package com.winlator.gtaiv;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** window.Native used by index.html. @JavascriptInterface methods run on a WebView background thread. */
public class NativeBridge {
    static final String[] ALL_FLAGS = {"-nomemrestrict", "-norestrictions", "-novblank", "-noprecache", "-windowed"};
    private static final String EXE = "GTAIV.exe";
    private static final String[] MOD_DIRS = {"", "plugins", "scripts"};

    private final Activity act;
    private final WebView web;
    private final SharedPreferences sp;

    public NativeBridge(Activity act, WebView web) {
        this.act = act;
        this.web = web;
        this.sp = act.getSharedPreferences("gtaiv_launcher", Context.MODE_PRIVATE);
    }

    /* ---------------- helpers ---------------- */
    private void js(final String code) {
        act.runOnUiThread(new Runnable() { public void run() { web.evaluateJavascript(code, null); } });
    }

    private void toast(final String m) {
        act.runOnUiThread(new Runnable() { public void run() { Toast.makeText(act, m, Toast.LENGTH_SHORT).show(); } });
    }

    static File findExe(File dir) {
        if (dir == null) return null;
        File[] kids = dir.listFiles();
        if (kids == null) return null;
        for (File f : kids) if (f.isFile() && f.getName().equalsIgnoreCase(EXE)) return f;
        return null;
    }

    private String folder() { return sp.getString("gameFolder", ""); }

    private String stateJson() {
        try {
            File exe = folder().isEmpty() ? null : findExe(new File(folder()));
            JSONObject s = new JSONObject();
            s.put("gameFolder", folder());
            s.put("exeFound", exe != null);
            s.put("gameVersion", "");
            s.put("lastPlayed", sp.getLong("lastPlayed", 0));
            s.put("totalMs", sp.getLong("totalMs", 0));
            s.put("engineReady", sp.getBoolean("engineReady", false));
            JSONObject st = new JSONObject();
            st.put("resolution", sp.getString("resolution", "1280x720"));
            st.put("driver", sp.getString("driver", "auto"));
            st.put("dxvk", sp.getString("dxvk", "auto"));
            st.put("hud", sp.getBoolean("hud", false));
            JSONArray fl = new JSONArray();
            String csv = sp.getString("flags", "-nomemrestrict,-norestrictions,-novblank");
            if (!csv.isEmpty()) for (String f : csv.split(",")) fl.put(f);
            st.put("flags", fl);
            s.put("settings", st);
            return s.toString();
        } catch (Exception e) { return "{}"; }
    }

    private void push() { js("window.onState&&window.onState(" + stateJson() + ")"); }

    /** Called from LauncherActivity.onResume: add play time after returning from the game. */
    void onResumed() {
        long start = sp.getLong("sessionStart", 0);
        if (start > 0) {
            long add = Math.max(0, System.currentTimeMillis() - start);
            sp.edit().putLong("totalMs", sp.getLong("totalMs", 0) + add).putLong("sessionStart", 0).apply();
        }
        push();
    }

    private List<String> rootList() {
        List<String> r = new ArrayList<>();
        File internal = Environment.getExternalStorageDirectory();
        if (internal != null && internal.canRead()) r.add(internal.getAbsolutePath());
        File[] st = new File("/storage").listFiles();
        if (st != null) for (File f : st) {
            String n = f.getName();
            if (n.equals("emulated") || n.equals("self") || !f.canRead()) continue;
            r.add(f.getAbsolutePath());
        }
        return r;
    }

    /* ---------------- bridge API ---------------- */
    @JavascriptInterface public void ready() { push(); }

    @JavascriptInterface public void exit() {
        act.runOnUiThread(new Runnable() { public void run() { act.finish(); } });
    }

    @JavascriptInterface public String allFlags() { return new JSONArray(Arrays.asList(ALL_FLAGS)).toString(); }

    @JavascriptInterface public String roots() { return new JSONArray(rootList()).toString(); }

    @JavascriptInterface public void pickFolder() { js("window.onOpenBrowser&&window.onOpenBrowser()"); }

    @JavascriptInterface public String listDir(String p) {
        try {
            File dir = new File(p);
            JSONObject o = new JSONObject();
            o.put("path", dir.getAbsolutePath());
            String parent = rootList().contains(dir.getAbsolutePath()) ? "" : (dir.getParent() == null ? "" : dir.getParent());
            o.put("parent", parent);
            o.put("hasExe", findExe(dir) != null);
            File[] kids = dir.listFiles();
            o.put("denied", kids == null);
            JSONArray dirs = new JSONArray();
            if (kids != null) {
                List<File> ds = new ArrayList<>();
                for (File k : kids) if (k.isDirectory() && !k.getName().startsWith(".")) ds.add(k);
                Collections.sort(ds, new Comparator<File>() {
                    public int compare(File a, File b) { return a.getName().compareToIgnoreCase(b.getName()); }
                });
                for (File k : ds) {
                    JSONObject d = new JSONObject();
                    d.put("name", k.getName());
                    d.put("path", k.getAbsolutePath());
                    d.put("hasExe", findExe(k) != null);
                    dirs.put(d);
                }
            }
            o.put("dirs", dirs);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    @JavascriptInterface public void setFolder(String p) {
        File d = new File(p);
        if (findExe(d) == null) toast("Ei folder e GTAIV.exe nai.");
        sp.edit().putString("gameFolder", d.getAbsolutePath()).apply();
        push();
    }

    @JavascriptInterface public void scan() {
        new Thread(new Runnable() { public void run() {
            JSONArray out = new JSONArray();
            long deadline = System.currentTimeMillis() + 90000;
            for (String r : rootList()) walk(new File(r), 0, out, deadline);
            js("window.onScan&&window.onScan(" + out.toString() + ")");
        } }).start();
    }

    private void walk(File dir, int depth, JSONArray out, long deadline) {
        if (depth > 7 || System.currentTimeMillis() > deadline) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (k.isFile() && k.getName().equalsIgnoreCase(EXE)) out.put(k.getAbsolutePath());
        }
        for (File k : kids) {
            String n = k.getName();
            if (!k.isDirectory() || n.startsWith(".") || (depth == 0 && n.equals("Android"))) continue;
            walk(k, depth + 1, out, deadline);
        }
    }

    @JavascriptInterface public void setSetting(String k, String v) {
        SharedPreferences.Editor e = sp.edit();
        if ("hud".equals(k)) e.putBoolean("hud", "true".equals(v));
        else if ("flags".equals(k) || "resolution".equals(k) || "driver".equals(k) || "dxvk".equals(k)) e.putString(k, v == null ? "" : v);
        e.apply();
        push();
    }

    /* ---------------- ASI mods ---------------- */
    @JavascriptInterface public void listMods() {
        new Thread(new Runnable() { public void run() {
            JSONArray arr = new JSONArray();
            try {
                String f = folder();
                if (!f.isEmpty()) for (String sub : MOD_DIRS) {
                    File d = sub.isEmpty() ? new File(f) : new File(f, sub);
                    File[] kids = d.listFiles();
                    if (kids == null) continue;
                    Arrays.sort(kids, new Comparator<File>() {
                        public int compare(File a, File b) { return a.getName().compareToIgnoreCase(b.getName()); }
                    });
                    for (File k : kids) {
                        String n = k.getName().toLowerCase();
                        boolean on = n.endsWith(".asi"), off = n.endsWith(".asi.disabled");
                        if (!k.isFile() || (!on && !off)) continue;
                        JSONObject m = new JSONObject();
                        m.put("name", off ? k.getName().substring(0, k.getName().length() - 9) : k.getName());
                        m.put("where", sub.isEmpty() ? "/" : "/" + sub);
                        m.put("enabled", on);
                        m.put("path", k.getAbsolutePath());
                        arr.put(m);
                    }
                }
            } catch (Exception ignored) {}
            js("window.onMods&&window.onMods(" + arr.toString() + ")");
        } }).start();
    }

    @JavascriptInterface public void toggleMod(String path, boolean enable) {
        File f = new File(path);
        String n = f.getName();
        File to = null;
        if (enable && n.toLowerCase().endsWith(".asi.disabled")) to = new File(f.getParentFile(), n.substring(0, n.length() - 9));
        else if (!enable && n.toLowerCase().endsWith(".asi")) to = new File(f.getParentFile(), n + ".disabled");
        if (to != null && !f.renameTo(to)) toast("Mod rename failed");
        listMods();
    }

    /* ---------------- play ---------------- */
    @JavascriptInterface public void play() {
        final File exe = folder().isEmpty() ? null : findExe(new File(folder()));
        if (exe == null) { js("window.onNeedFolder&&window.onNeedFolder()"); return; }
        sp.edit().putLong("lastPlayed", System.currentTimeMillis())
                .putLong("sessionStart", System.currentTimeMillis()).apply();
        final GameLauncher.Config c = new GameLauncher.Config();
        c.exe = exe;
        c.resolution = sp.getString("resolution", "1280x720");
        c.driver = sp.getString("driver", "auto");
        c.dxvk = sp.getString("dxvk", "auto");
        c.hud = sp.getBoolean("hud", false);
        c.flags = sp.getString("flags", "");
        act.runOnUiThread(new Runnable() { public void run() {
            try {
                GameLauncher.launch(act, c);
                sp.edit().putBoolean("engineReady", true).apply();
            } catch (Throwable t) {
                sp.edit().putLong("sessionStart", 0).apply();
                Toast.makeText(act, "Launch failed: " + t, Toast.LENGTH_LONG).show();
                push();
            }
        } });
    }
}
