package com.winlator.gtaiv;

import android.app.Activity;
import android.content.Intent;

import java.io.File;
import java.io.FileOutputStream;

/**
 * The ONLY file that touches Winlator internals. It writes a .desktop shortcut into a container and
 * starts Winlator's XServerDisplayActivity with it (same mechanism as home-screen shortcuts).
 * Class / extra names below follow Winlator Bionic; verify them against the Ludashi 4.1 source.
 */
public class GameLauncher {
    // ---- adjust these to match Ludashi 4.1 ----
    static final String XSERVER_ACTIVITY = "com.winlator.XServerDisplayActivity";
    static final int CONTAINER_ID = 1;          // container to run the game in
    static final String EXTRA_CONTAINER = "container_id";
    static final String EXTRA_SHORTCUT = "shortcut_path";

    public static class Config {
        public File exe;
        public String resolution, driver, dxvk, flags;
        public boolean hud;
    }

    public static void launch(Activity a, Config c) throws Exception {
        File home = new File(a.getFilesDir(), "imagefs/home/xuser-" + CONTAINER_ID);
        File desktop = new File(home, ".wine/drive_c/users/xuser/Desktop");
        if (!desktop.isDirectory() && !desktop.mkdirs())
            throw new IllegalStateException("Container " + CONTAINER_ID + " not found. Create it once in Winlator first.");
        File sc = new File(desktop, "GTAIV.desktop");

        StringBuilder s = new StringBuilder();
        s.append("[Desktop Entry]\nName=GTA IV\nType=Application\nStartupWMClass=explorer\n");
        s.append("Exec=env WINEPREFIX=\"/home/xuser/.wine\" wine \"").append(winPath(c.exe)).append("\"");
        if (c.flags != null && !c.flags.isEmpty()) s.append(' ').append(c.flags.replace(',', ' '));
        s.append("\nPath=").append(c.exe.getParent()).append("\n\n[Extra Data]\n");
        s.append("screenSize=").append(c.resolution).append('\n');
        if (!"auto".equals(c.driver)) s.append("graphicsDriver=").append(c.driver).append('\n');
        s.append("dxwrapper=dxvk\n");
        if (!"auto".equals(c.dxvk)) s.append("dxwrapperConfig=version=").append(c.dxvk).append('\n');
        s.append("showFPS=").append(c.hud ? "1" : "0").append('\n');
        FileOutputStream o = new FileOutputStream(sc);
        o.write(s.toString().getBytes("UTF-8"));
        o.close();

        Intent i = new Intent(a, Class.forName(XSERVER_ACTIVITY));
        i.setAction(Intent.ACTION_MAIN);
        i.putExtra(EXTRA_CONTAINER, CONTAINER_ID);
        i.putExtra(EXTRA_SHORTCUT, sc.getPath());
        a.startActivity(i);
    }

    /** Path of the exe as Wine sees it. Winlator maps Android storage to a drive in container settings
     *  (e.g. D: = /storage/emulated/0/Download). Change this to match the drive you mapped. */
    static String winPath(File exe) {
        return "Z:" + exe.getAbsolutePath().replace('/', '\\');
    }
}
