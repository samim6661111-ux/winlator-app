#!/usr/bin/env python3
"""Run from the repo root: copies overlay/files/* over the source and patches the manifest."""
import os, re, shutil, sys

ROOT = os.getcwd()
SRC = os.path.join(ROOT, "overlay", "files")
for dp, _, fns in os.walk(SRC):
    for fn in fns:
        s = os.path.join(dp, fn)
        d = os.path.join(ROOT, os.path.relpath(s, SRC))
        os.makedirs(os.path.dirname(d), exist_ok=True)
        shutil.copyfile(s, d)
        print("copied", os.path.relpath(d, ROOT))

mf = os.path.join(ROOT, "app/src/main/AndroidManifest.xml")
t = open(mf, encoding="utf-8").read()
if "com.winlator.gtaiv.LauncherActivity" not in t:
    t = re.sub(r'\s*<category\s+android:name="android\.intent\.category\.LAUNCHER"\s*/>', "", t)
    act = '''
        <activity android:name="com.winlator.gtaiv.LauncherActivity"
            android:exported="true"
            android:screenOrientation="sensorLandscape"
            android:configChanges="orientation|screenSize|keyboardHidden|smallestScreenSize|screenLayout"
            android:theme="@android:style/Theme.Black.NoTitleBar.Fullscreen">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
'''
    t = t.replace("</application>", act + "    </application>", 1)
    perms = ""
    for p in ["MANAGE_EXTERNAL_STORAGE", "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE"]:
        if "android.permission." + p not in t:
            perms += '    <uses-permission android:name="android.permission.%s"/>\n' % p
    t = re.sub(r"(<application\b)", perms + r"    \1", t, count=1)
    open(mf, "w", encoding="utf-8").write(t)
    print("manifest patched")

# optional: APP_ID=com.example.ludashiiv python3 overlay/apply.py
new_id = os.environ.get("APP_ID")
if new_id:
    for g in ("app/build.gradle", "app/build.gradle.kts"):
        p = os.path.join(ROOT, g)
        if os.path.exists(p):
            c = open(p, encoding="utf-8").read()
            c2 = re.sub(r'(applicationId\s*=?\s*)"[^"]+"', r'\1"%s"' % new_id, c)
            open(p, "w", encoding="utf-8").write(c2)
            print("applicationId ->", new_id, "in", g)
