package com.winlator;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.container.Shortcut;
import com.winlator.core.AppUtils;
import com.winlator.core.FileUtils;
import com.winlator.xenvironment.RootFSInstaller;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * GTA IV Launcher home screen.
 *
 * Shows the HTML UI in assets/launcher and drives the embedded Winlator engine:
 * installs the system files on first run, creates a dedicated "GTA IV" container,
 * writes a shortcut to GTAIV.exe and starts the game directly (no Winlator menus).
 */
public class LauncherActivity extends AppCompatActivity {
    private static final String CONTAINER_NAME = "GTA IV";
    private static final String EXE_NAME = "GTAIV.exe";
    private static final String CONTROLS_PROFILE_ID = "5"; // assets/inputcontrols/profiles/controls-5.icp
    private static final int REQUEST_PICK_FOLDER = 101;
    private static final int REQUEST_STORAGE = 102;

    // Preference keys
    private static final String P_FOLDER = "gta_folder";
    private static final String P_LAST_PLAYED = "gta_last_played";
    private static final String P_TOTAL_MS = "gta_total_ms";
    private static final String P_SESSION_START = "gta_session_start";
    private static final String P_RESOLUTION = "gta_resolution";
    private static final String P_DRIVER = "gta_driver";      // auto | turnip | vortek
    private static final String P_DXVK = "gta_dxvk";          // 1.10.3 | 2.4.1
    private static final String P_HUD = "gta_hud";            // boolean
    private static final String P_FLAGS = "gta_flags";        // comma separated

    private static final String[] ALL_FLAGS = {"-nomemrestrict", "-norestrictions", "-novblank", "-noprecache", "-windowed"};
    private static final String[] DEFAULT_FLAGS = {"-nomemrestrict", "-norestrictions", "-novblank"};

    private WebView webView;
    private SharedPreferences prefs;
    private boolean launching = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        webView = new WebView(this);
        setContentView(webView);
        hideSystemBars();

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setMediaPlaybackRequiresUserGesture(false);
        webView.setBackgroundColor(0xFF070B14);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "Native");
        webView.loadUrl("file:///android_asset/launcher/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
        launching = false;
        finishPlaySession();
        pushState();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    public void onBackPressed() {
        // Let the HTML UI handle "back" (close dialogs / go Home); it calls Native.exit() when at Home.
        webView.evaluateJavascript("window.onBack && window.onBack()", null);
    }

    private void hideSystemBars() {
        AppUtils.hideSystemUI(this);
    }

    // ------------------------------------------------------------------ state

    private File gameDir() {
        String path = prefs.getString(P_FOLDER, "");
        return path.isEmpty() ? null : new File(path);
    }

    private boolean hasExe() {
        File dir = gameDir();
        return dir != null && findExe(dir) != null;
    }

    /** Case-insensitive lookup so GTAIV.exe / gtaiv.exe both work. */
    private static File findExe(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) if (f.isFile() && f.getName().equalsIgnoreCase(EXE_NAME)) return f;
        return null;
    }

    private void finishPlaySession() {
        long start = prefs.getLong(P_SESSION_START, 0);
        if (start > 0) {
            long elapsed = Math.max(0, System.currentTimeMillis() - start);
            prefs.edit()
                .putLong(P_TOTAL_MS, prefs.getLong(P_TOTAL_MS, 0) + elapsed)
                .putLong(P_SESSION_START, 0)
                .apply();
        }
    }

    private JSONObject buildState() throws JSONException {
        JSONObject state = new JSONObject();
        File dir = gameDir();
        File exe = dir != null ? findExe(dir) : null;

        state.put("gameFolder", dir != null ? dir.getPath() : "");
        state.put("exeFound", exe != null);
        state.put("gameVersion", exe != null ? readExeVersion(exe) : "");
        state.put("lastPlayed", prefs.getLong(P_LAST_PLAYED, 0));
        state.put("totalMs", prefs.getLong(P_TOTAL_MS, 0));
        state.put("engineReady", RootFSInstaller.isInstalled(this));

        JSONObject settings = new JSONObject();
        settings.put("resolution", prefs.getString(P_RESOLUTION, "1280x720"));
        settings.put("driver", prefs.getString(P_DRIVER, "auto"));
        settings.put("dxvk", prefs.getString(P_DXVK, "1.10.3"));
        settings.put("hud", prefs.getBoolean(P_HUD, false));
        JSONArray flags = new JSONArray();
        for (String f : getFlags()) flags.put(f);
        settings.put("flags", flags);
        state.put("settings", settings);
        return state;
    }

    private void pushState() {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                final String json = buildState().toString();
                runOnUiThread(() -> webView.evaluateJavascript("window.onState && window.onState(" + json + ")", null));
            }
            catch (JSONException e) {}
        });
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
    }

    private List<String> getFlags() {
        String stored = prefs.getString(P_FLAGS, null);
        if (stored == null) return new ArrayList<>(Arrays.asList(DEFAULT_FLAGS));
        List<String> out = new ArrayList<>();
        for (String f : stored.split(",")) if (!f.trim().isEmpty()) out.add(f.trim());
        return out;
    }

    /** Reads FileVersion out of the exe's VERSIONINFO resource (UTF-16 string scan). Returns "" if not found. */
    private static String readExeVersion(File exe) {
        final byte[] key = "F\0i\0l\0e\0V\0e\0r\0s\0i\0o\0n\0\0\0".getBytes(StandardCharsets.ISO_8859_1);
        final int chunk = 1 << 20;
        try (RandomAccessFile raf = new RandomAccessFile(exe, "r")) {
            byte[] buf = new byte[chunk + 256];
            long pos = 0;
            int carry = 0;
            while (pos < raf.length()) {
                raf.seek(pos);
                int n = raf.read(buf, carry, chunk);
                if (n <= 0) break;
                int len = carry + n;
                for (int i = 0; i + key.length + 64 < len; i++) {
                    int k = 0;
                    while (k < key.length && buf[i + k] == key[k]) k++;
                    if (k == key.length) {
                        int j = i + key.length;
                        // skip alignment padding
                        while (j + 1 < len && buf[j] == 0 && buf[j + 1] == 0) j += 2;
                        StringBuilder sb = new StringBuilder();
                        while (j + 1 < len && !(buf[j] == 0 && buf[j + 1] == 0) && sb.length() < 24) {
                            sb.append((char)(buf[j] & 0xff));
                            j += 2;
                        }
                        String v = sb.toString().trim().replace(',', '.').replace(" ", "");
                        if (v.matches("\\d+(\\.\\d+){1,3}")) return v;
                    }
                }
                carry = Math.min(256, len);
                System.arraycopy(buf, len - carry, buf, 0, carry);
                pos += n;
            }
        }
        catch (IOException e) {}
        return "";
    }

    // ------------------------------------------------------------------ mods (ASI plugins)

    private static final String[] MOD_DIRS = {"", "plugins", "scripts"};

    private JSONArray listMods() throws JSONException {
        JSONArray mods = new JSONArray();
        File dir = gameDir();
        if (dir == null) return mods;
        for (String sub : MOD_DIRS) {
            File base = sub.isEmpty() ? dir : new File(dir, sub);
            File[] files = base.listFiles();
            if (files == null) continue;
            Arrays.sort(files);
            for (File f : files) {
                String name = f.getName();
                String lower = name.toLowerCase();
                boolean enabled = lower.endsWith(".asi");
                boolean disabled = lower.endsWith(".asi.disabled");
                if (!f.isFile() || !(enabled || disabled)) continue;
                JSONObject m = new JSONObject();
                m.put("name", disabled ? name.substring(0, name.length() - ".disabled".length()) : name);
                m.put("path", f.getPath());
                m.put("where", sub.isEmpty() ? "/" : "/" + sub);
                m.put("enabled", enabled);
                mods.put(m);
            }
        }
        return mods;
    }

    private boolean toggleMod(String path, boolean enable) {
        File dir = gameDir();
        File f = new File(path);
        // only allow files inside the chosen game folder
        try {
            if (dir == null || !f.getCanonicalPath().startsWith(dir.getCanonicalPath() + File.separator)) return false;
        }
        catch (IOException e) {
            return false;
        }
        String name = f.getName();
        File target;
        if (enable && name.toLowerCase().endsWith(".asi.disabled")) {
            target = new File(f.getParentFile(), name.substring(0, name.length() - ".disabled".length()));
        }
        else if (!enable && name.toLowerCase().endsWith(".asi")) {
            target = new File(f.getParentFile(), name + ".disabled");
        }
        else return false;
        return f.renameTo(target);
    }

    // ------------------------------------------------------------------ folder picking

    private void pickFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        startActivityForResult(intent, REQUEST_PICK_FOLDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_FOLDER && resultCode == RESULT_OK && data != null && data.getData() != null) {
            String path = treeUriToPath(data.getData());
            if (path == null) {
                toast("Ei folder ta pawa gelo na. Phone er internal storage er moddhe folder select koro.");
                return;
            }
            prefs.edit().putString(P_FOLDER, path).apply();
            if (!hasExe()) toast("Ei folder e GTAIV.exe nai. Jekhane GTAIV.exe ache sheta select koro.");
            pushState();
        }
    }

    /** content://com.android.externalstorage.documents/tree/primary:Games/GTAIV -> /storage/emulated/0/Games/GTAIV */
    private static String treeUriToPath(Uri uri) {
        try {
            String docId = DocumentsContract.getTreeDocumentId(uri);
            int colon = docId.indexOf(':');
            if (colon < 0) return null;
            String volume = docId.substring(0, colon);
            String rel = docId.substring(colon + 1);
            File root = volume.equalsIgnoreCase("primary")
                ? Environment.getExternalStorageDirectory()
                : new File("/storage/" + volume);
            return rel.isEmpty() ? root.getPath() : new File(root, rel).getPath();
        }
        catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ play

    private boolean hasStoragePermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startPlay();
            else toast("Storage permission lagbe, na hole game folder poRa jabe na.");
        }
    }

    private void startPlay() {
        if (launching) return;

        if (!hasExe()) {
            toast("Age GTA IV folder select koro (jekhane GTAIV.exe ache).");
            webView.evaluateJavascript("window.onNeedFolder && window.onNeedFolder()", null);
            return;
        }
        if (!hasStoragePermission()) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_STORAGE);
            return;
        }

        launching = true;
        // 1) system files (first run only)  2) container  3) shortcut  4) start game
        RootFSInstaller.installIfNeeded(this, this::prepareContainerAndLaunch);
        // if installation was cancelled/failed the flag must be reset
        webView.postDelayed(() -> { if (!RootFSInstaller.isInstalled(this)) launching = false; }, 1500);
    }

    private void prepareContainerAndLaunch() {
        final ContainerManager manager = new ContainerManager(this);
        Container existing = null;
        for (Container c : manager.getContainers()) {
            if (CONTAINER_NAME.equals(c.getName())) { existing = c; break; }
        }

        if (existing != null) {
            applySettings(existing);
            existing.saveData();
            writeShortcutAndLaunch(manager, existing);
        }
        else {
            try {
                JSONObject data = new JSONObject();
                data.put("name", CONTAINER_NAME);
                data.put("screenSize", prefs.getString(P_RESOLUTION, "1280x720"));
                data.put("envVars", Container.DEFAULT_ENV_VARS);
                data.put("cpuList", Container.getFallbackCPUList());
                data.put("cpuListWoW64", Container.getFallbackCPUList());
                data.put("graphicsDriver", resolveGraphicsDriver());
                data.put("dxwrapper", "dxvk");
                data.put("dxwrapperConfig", dxvkConfig());
                data.put("audioDriver", Container.DEFAULT_AUDIO_DRIVER);
                data.put("wincomponents", gtaWinComponents());
                data.put("drives", drivesString());
                data.put("hudMode", hudMode());
                data.put("startupSelection", Container.STARTUP_SELECTION_ESSENTIAL);
                data.put("box64Preset", com.winlator.box64.Box64Preset.DEFAULT);
                data.put("desktopTheme", com.winlator.core.WineThemeManager.DEFAULT_DESKTOP_THEME);

                com.winlator.core.PreloaderDialog dialog = new com.winlator.core.PreloaderDialog(this);
                dialog.show(R.string.loading);
                manager.createContainerAsync(data, (container) -> {
                    dialog.close();
                    if (container == null) {
                        launching = false;
                        toast("Container banano gelo na. Storage faka ache kina dekho.");
                        return;
                    }
                    writeShortcutAndLaunch(manager, container);
                });
            }
            catch (JSONException e) {
                launching = false;
            }
        }
    }

    private String resolveGraphicsDriver() {
        String pref = prefs.getString(P_DRIVER, "auto");
        String glDriver = com.winlator.container.GraphicsDrivers.DEFAULT_OPENGL_DRIVER;
        switch (pref) {
            case "turnip": return "turnip," + glDriver;
            case "vortek": return "vortek," + glDriver;
            default: return com.winlator.container.GraphicsDrivers.getDefaultDriver(this);
        }
    }

    private String dxvkConfig() {
        return "version=" + prefs.getString(P_DXVK, "1.10.3") + ",framerate=0,maxDeviceMemory=0";
    }

    /** DirectX 9 DLLs (d3dx9_*), VC++ 2005/2010, XAudio, DirectSound/Music are pre-enabled for GTA IV. */
    private String gtaWinComponents() {
        return "direct3d=1,directsound=1,directmusic=1,directshow=0,directplay=0,xaudio=1,vcrun2005=1,vcrun2010=1,wmdecoder=1";
    }

    private String drivesString() {
        File dir = gameDir();
        return "D:" + (dir != null ? dir.getPath() : AppUtils.DIRECTORY_DOWNLOADS) + "E:" + AppUtils.INTERNAL_STORAGE;
    }

    private byte hudMode() {
        return (byte)(prefs.getBoolean(P_HUD, false)
            ? com.winlator.widget.FrameRating.Mode.SIMPLE.ordinal()
            : com.winlator.widget.FrameRating.Mode.DISABLED.ordinal());
    }

    private void applySettings(Container c) {
        c.setScreenSize(prefs.getString(P_RESOLUTION, "1280x720"));
        c.setGraphicsDriver(resolveGraphicsDriver());
        c.setDXWrapper("dxvk");
        c.setDXWrapperConfig(dxvkConfig());
        c.setWinComponents(gtaWinComponents());
        c.setDrives(drivesString());
        c.setHUDMode(hudMode());
    }

    private void writeCommandLine() {
        File dir = gameDir();
        if (dir == null) return;
        StringBuilder sb = new StringBuilder();
        for (String f : getFlags()) sb.append(f).append("\r\n");
        // commandline.txt is read by GTAIV.exe from its own folder
        FileUtils.writeString(new File(dir, "commandline.txt"), sb.toString());
    }

    private void writeShortcutAndLaunch(ContainerManager manager, Container container) {
        try {
            writeCommandLine();

            // make sure the GTA IV touch profile exists (it is only auto-copied on a fresh install)
            File profileFile = new File(com.winlator.inputcontrols.InputControlsManager.getProfilesDir(this), "controls-" + CONTROLS_PROFILE_ID + ".icp");
            if (!profileFile.exists()) FileUtils.copy(this, "inputcontrols/profiles/controls-" + CONTROLS_PROFILE_ID + ".icp", profileFile);

            File desktopDir = new File(container.getUserDir(), "Desktop");
            if (!desktopDir.isDirectory()) desktopDir.mkdirs();
            File file = new File(desktopDir, CONTAINER_NAME + ".desktop");

            String exe = findExe(gameDir()).getName();
            String content = "[Desktop Entry]\n"
                + "Name=" + CONTAINER_NAME + "\n"
                + "Exec=env WINEPREFIX=\"/home/xuser/.wine\" wine D:\\\\" + exe + "\n"
                + "Type=Application\n"
                + "StartupNotify=true\n"
                + "Path=/home/xuser/.wine/dosdevices/d:\n"
                + "StartupWMClass=" + exe + "\n";
            FileUtils.writeString(file, content);

            Shortcut shortcut = new Shortcut(container, file);
            shortcut.putExtra("controlsProfile", CONTROLS_PROFILE_ID);
            shortcut.putExtra("screenSize", prefs.getString(P_RESOLUTION, "1280x720"));
            shortcut.saveData();

            prefs.edit()
                .putLong(P_LAST_PLAYED, System.currentTimeMillis())
                .putLong(P_SESSION_START, System.currentTimeMillis())
                .apply();

            Intent intent = new Intent(this, XServerDisplayActivity.class);
            intent.putExtra("container_id", container.id);
            intent.putExtra("shortcut_path", file.getPath());
            startActivity(intent);
        }
        catch (Exception e) {
            launching = false;
            toast("Game start korte somossha: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ JS bridge

    private class Bridge {
        @JavascriptInterface
        public void ready() { pushState(); }

        @JavascriptInterface
        public void pickFolder() { runOnUiThread(LauncherActivity.this::pickFolder); }

        @JavascriptInterface
        public void play() { runOnUiThread(LauncherActivity.this::startPlay); }

        @JavascriptInterface
        public void exit() { runOnUiThread(LauncherActivity.this::finish); }

        @JavascriptInterface
        public void openAdvanced() {
            runOnUiThread(() -> startActivity(new Intent(LauncherActivity.this, MainActivity.class)));
        }

        @JavascriptInterface
        public void setSetting(String key, String value) {
            SharedPreferences.Editor e = prefs.edit();
            switch (key) {
                case "resolution": e.putString(P_RESOLUTION, value); break;
                case "driver": e.putString(P_DRIVER, value); break;
                case "dxvk": e.putString(P_DXVK, value); break;
                case "hud": e.putBoolean(P_HUD, Boolean.parseBoolean(value)); break;
                case "flags": e.putString(P_FLAGS, value); break;
            }
            e.apply();
            pushState();
        }

        @JavascriptInterface
        public void listMods() {
            Executors.newSingleThreadExecutor().execute(() -> {
                try {
                    final String json = LauncherActivity.this.listMods().toString();
                    runOnUiThread(() -> webView.evaluateJavascript("window.onMods && window.onMods(" + json + ")", null));
                }
                catch (JSONException e) {}
            });
        }

        @JavascriptInterface
        public void toggleMod(String path, boolean enable) {
            boolean ok = LauncherActivity.this.toggleMod(path, enable);
            if (!ok) toast("Mod ta toggle kora gelo na.");
            listMods();
        }

        @JavascriptInterface
        public String allFlags() {
            return new JSONArray(Arrays.asList(ALL_FLAGS)).toString();
        }
    }
}
