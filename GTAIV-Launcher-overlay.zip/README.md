# GTA IV Launcher (Android)

Winlator (LGPL-2.1) engine er upor banano GTA IV launcher. App open korle ei UI ashe, **PLAY GAME** chaple
system files install (prothom bar) -> "GTA IV" container auto toiri -> `GTAIV.exe` sorasori start.

## APK build (PC e Android SDK lagbe na)
1. Ei folder ta GitHub e ekta notun repo te upload koro (branch: `main`).
2. Repo > **Actions > Build APK > Run workflow**.
3. Shesh hole **Artifacts > GTAIV-Launcher-apk** theke APK nammao.

Ba Android Studio te khule `Build > Build APK`. (NDK 24.0.8215888, CMake 3.22.1)

## Notes
- `applicationId` ta `com.winlator` e-i rakha hoyeche (rootfs e path hardcoded). Tai asol Winlator install thakle age uninstall koro.
- Game files app e nai. Phone e GTA IV folder rakho, app e select koro.
- Artwork: `app/src/main/assets/launcher/img/hero.jpg` (background) ar `logo.png` dile UI te dekhabe.
- Touch layout: `assets/inputcontrols/profiles/controls-5.icp` (virtual gamepad, GTA IV labels).
- VC++ x86 redist: `assets/redist/VC_redist.x86.exe` (Winlator > Advanced > Start Menu theke install kora jay).
- Mods: game folder / `plugins` / `scripts` er `.asi` file Mods tab e on/off hoy (ASI loader `dinput8.dll` lagbe).
- GTA IV 1.0.7.0 e GFWL (xlive.dll) jhamela kore; 1.2.0.x + FusionFix recommended.
